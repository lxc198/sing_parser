from .music_parse import *

__doc__ = music_parse.__doc__
if hasattr(music_parse, "__all__"):
    __all__ = music_parse.__all__